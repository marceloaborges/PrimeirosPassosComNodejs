import {mod1, mod2} from "./modulos";

mod1();
mod2();
