export function mod1() {
  console.log('Módulo 1 carregado');
}
export function mod2() {
  console.log('Módulo 2 carregado');
}
