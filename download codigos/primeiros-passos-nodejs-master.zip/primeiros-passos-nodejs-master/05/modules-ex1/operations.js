module.exports = {
  var1: 1,
  var2: 2
}
