exports.adicao = (x,y) => x + y;
exports.subtracao = (x,y) => x - y;
