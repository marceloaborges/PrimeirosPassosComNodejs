const funcoes2 = require('./funcoes2');

const add = funcoes2.adicao(5,7);
const sub = funcoes2.subtracao(7,3);

console.log(add, sub);
